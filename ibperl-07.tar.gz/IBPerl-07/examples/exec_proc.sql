CREATE DATABASE 'test_exec.gdb';

SET TERM ^;
CREATE PROCEDURE FOO
    (intarg INTEGER, charg CHAR(10))
    RETURNS (a INTEGER, b CHAR(10), c INTEGER)
AS
BEGIN
  a = 10 - intarg;
  b = 'foofah';
  c = 42;
END^
