/*
 * Hit.sql - InterBase SQL script to create a database
 * used by pagehit.pl, an example CGI application using
 * IBPerl 0.2 to record page hits on a web server.
 * Copyright 1996 Bill Karwin
 */
CREATE DATABASE "hit.gdb";

CREATE TABLE HIT_LOG (
	URL     CHAR(100) NOT NULL,
	DAY     DATE NOT NULL,
	HOST    CHAR(30)
);
