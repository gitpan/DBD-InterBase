#!/usr/local/bin/perl
# Pagehit.pl - Example CGI script using IBPerl 0.2
# to provide a page hit counter that stores data into
# an InterBase database.
# Copyright 1996 Bill Karwin

use IBPerl;

print "Content-type: text/plain\r\n\n";

$db = new IBPerl::Connection(
	Server   => 'www',
	Path     => '/usr/httpd/data/hit.gdb',
	User     => 'sysdba',
	Password => 'masterkey');

$tr = new IBPerl::Transaction( Database => $db );

$query = "INSERT INTO HIT_LOG VALUES ( \"$ENV{DOCUMENT_NAME}\", \"TODAY\", \"" .  ( $ENV{REMOTE_HOST} || $ENV{REMOTE_ADDR} ) . "\")" ;

$st = new IBPerl::Statement( Transaction => $tr, Stmt => $query );

if ( $st->execute ) { print "$st->{Error}\n"; }

$tr->commit;
$db->disconnect;

print "Your access to this page has been recorded for purposes of gathering statistics.<P>\n";

print "Query = $query<P>\n";

foreach $i (keys %ENV) {
    print "\$ENV{ $i } = $ENV{$i}<BR>\n";
}

exit(0);
