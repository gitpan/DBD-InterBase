#!/usr/local/bin/perl
# rnd.pl -- Example Perl script using IBPerl to
# populate fictional data into hit.gdb, an InterBase
# database.
# Copyright 1996 Bill Karwin

use IBPerl;

open(HL, "hosts");
@hosts = <HL>;
close(HL);
grep(chop($_), @hosts);

open(UL, "urls");
@urls = <UL>;
close(UL);
grep(chop($_), @urls);

$db = new IBPerl::Connection( Server=>'www', Path=>'/usr/httpd/data/hit.gdb', User=>'sysdba', Password=>'masterkey');

$tr = new IBPerl::Transaction( Database => $db );

srand($$);

for ($i = 0; $i < 1000; $i++) 
{
    $rando = rand();
    if ($rando < 0.3) { $host = "compuserve.com"; }
    elsif ($rando < 0.5) { $host = "aol.com"; }
    else { $host = $hosts[int(rand($#hosts))]; }

    $url = $urls[int(rand($#urls))];

    $hitdate = int(rand(30)) . '-' . ('JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL')[int(rand(7))] . '-1996';

    $query = "INSERT INTO HIT_LOG VALUES (\"$url\", \"$hitdate\", \"$host\")";
    print "$query\n";

    $st = new IBPerl::Statement( Transaction => $tr, Stmt => $query );
    $st->execute;
}
$tr->commit;
$db->disconnect;
exit 0;
