You'll have to restore each database before running these tests.
Sorry, but distributing databases instead of backup files would've
added a lot to the size of this distribution. 
