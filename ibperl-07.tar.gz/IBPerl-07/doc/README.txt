                        Announcing a new public release
                         of IBPerl, the Perl 5 module
                           for InterBase V4 and V5

                       Copyright (c) 1996-1999 by Bill Karwin

What is IBPerl?

    IBPerl is an object-oriented class module and extension for Perl 5.
    The module provides an interface to the InterBase API library, for
    programming dynamic SQL applications with the RDBMS server product
    from InterBase Software Corp.  IBPerl is available for free,
    distributable under the GNU GPL or the Perl Artistic License.

Why would you want this?

    IBPerl provides a Perl-ish programming interface to InterBase.
    Any Perl script for which you wish you had a real OLTP database
    backend you can now write.  CGI scripts for the Web, interactive
    applications, automation or systems administration tools that
    need database access, anything!

Where can you get IBPerl?

    http://www.interbase.com/download.html

How do you use IBPerl?

    It comes with reference documentation, as a "pod" file (viewable
    in HTML at the above web site).  The distribution also contains
    example scripts.

What else do you need to use IBPerl?

    Perl 5.004, and InterBase 4.0 or higher.  You must have
    the InterBase product in order to compile and use IBPerl.

How do I install it?

    Assuming that you have Perl 5.004 installed and running on your
    system, follow these steps (on UNIX/Linux):

    1. Unpack the IBPerl archive:
       gzcat IBPerl-07.tar.gz | tar xvf -

    2. Change to the IBPerl directory:
       cd IBPerl-07

    3. Configure the Makefile:
       perl Makefile.PL
       This should create an appropriate Makefile for your platform,
       based on the rules described in Makefile.PL

    4. Build the IBPerl extension:
       make

    5. Install the IBPerl extension:
       make install

    On Win32, there is a pre-compiled binary of the IBPerl software.
    Follow these steps:

    1. Unzip the IBPerl archive with WinZip or PKZIP

    2. Change to the IBPerl directory:
       cd IBPerl-07
    
    3. Run the Install script:
       perl Install

    On Win32, you can use Gurusamy Sarathy's binary distribution of
    perl for Win32.  I know this to work correctly with IBPerl.
    If you use the ActiveState Perl distribution, you must upgrade to
    version 507.  Version 507 claims to work correctly with Perl extensions.
    
What platforms are supported?

    I develop IBPerl on Linux and Solaris.  I test on Win32 as well.
    IBPerl is known to run on SCO OpenServer, HP-UX, FreeBSD, etc.
    Any platform that has an InterBase client library can work with
    IBPerl.

What is InterBase?

    An SQL-92 conformant RDBMS and database application development
    product that operates on Windows 95/NT, NetWare, Linux, and several
    popular UNIX flavors.  Read some of the material on
    http://www.interbase.com/ for a full description of this product.

What version is IBPerl?

    This is the announcement for Beta release 0.7.  IBPerl will undergo
    quite a bit of changes in the future, to add more functionality,
    more portability, and better interoperability with the InterBase
    API, and the DBI and Interperl standards.  I want to make it
    available as soon as possible, though.

What was that about DBI?  Is there a DBD::InterBase package?

    No, IBPerl does not currently conform to the DBI interface.  My plan is
    eventually to implement a DBD driver that allows the DBI package to
    access IBPerl.

What's new in this version?

    - Binary distribution for Win32
    - More documentation and examples
    - Simple Install script
    - Many bug fixes, more robust code
    - Lengths statement property
    - DateFormat = 'tm' returns list a la localtime()

IBPerl is a contributed freeware software package, and neither
Bill Karwin, InterBase Software Corp., nor INPRISE Corp.
are responsible for damages resulting from its use or misuse.

--
Bill Karwin (bkarwin@interbase.com)
InterBase Software Corporation
